package com.lanches.lanchonete;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LanchoneteApplicationTests {

	@Test
	void contextLoads() {
	}

}
